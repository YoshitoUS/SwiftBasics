// 8.1 引数なしで、コンソールに「Hello」と出力する関数`greet`を作成してください。

// 8.2 引数firstNameとlastNameを受け取り、２つを連結した一つの文字列をコンソールに出力する関数を実装してください。

func greet() -> Void{
    print("Hello")
}

greet()

func name(firstName: String, lastName: String) -> Void{
    print(firstName + " " + lastName)
}

name(firstName: "Yoshito", lastName: "Usui")
