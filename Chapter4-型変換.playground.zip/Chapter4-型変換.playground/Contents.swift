// 4.1 整数型の変数intValueを定義し、値を5に設定してください。

// 4.2 intValueをDouble型に変換し、変数doubleValueに代入してください。

// 4.3 floatValueという名前のFloat型の変数を作成し、値を7.5に設定してください。

// 4.4 floatValueをInt型に変換し、変数integerValueに代入してください。

// 4.5 String型の変数stringValueを定義し、値を"42"に設定してください。

// 4.6 stringValueをInt型に変換し、変数intValueFromStringに代入してください。
var intValue: Int = 5
var doubleValue:Double = Double(intValue)
print(doubleValue)

var floatValue: Float = 7.5
var integerValue:Int = Int(floatValue)
print(integerValue)

var stringValue:String = "42"
var intValueFromString:Int = Int(stringValue)!
print(intValueFromString)
