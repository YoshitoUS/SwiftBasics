// 3.1 53から3を引いた結果を整数でprintしてください。


// 3.2 4を2で割った結果をprintしてください。


// 3.3 4と2.5をかけた結果をprintしてください。

let difference = 53 - 3
print(difference)

let quotient = 4/2
print(quotient)

let product = 4*2.5
print(product)
