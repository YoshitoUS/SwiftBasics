// 2.1 String型の変数「language」を定義して値として「Swift」を代入してください。


// 2.2 2.1で定義した変数をコンソールに出力してください


// 2.3 Int型の変数「version」を定義して値として「5」を代入してください。


// 2.4 2.3で定義した変数をコンソールに出力してください


// 2.5 Bool型の変数「bool」を定義して値として「true」を代入してください。


// 2.6 2.5で定義した変数をコンソールに出力してください

var launguage: String = "Swift"
print(launguage)

var version: Int = 5
print(version)

var bool:Bool = true
print(bool)
