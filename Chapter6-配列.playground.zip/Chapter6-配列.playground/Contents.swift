// 6.1 配列numbersの左から1つ目の値をコンソールに出力してください
let numbers = [1, 3, 5]
print(numbers[0])

// 6.2 配列numbersの左から3つ目の値をコンソールに出力してください
print(numbers[2])

// 6.3 配列coursesに"iPhone"をコンソールに追加してください
var courses = ["WebD", "WebS", "Android"]
courses.append("iPhone")
print(courses)

