// 0.1 print関数を使ってHello World!とコンソールに出力してください。

// 0.2 0.1で書いたprint関数をコメントアウトして実行されないことを確認してください。


print("Hello world!")
//print("Hello world!")
