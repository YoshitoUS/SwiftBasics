// 1.1 Int型の変数「count」を定義して「1」を代入してください


// 1.2 1.1で定義した変数「count」に「2」を再代入してください



// 1.3 String型の定数「name」を定義して「John」を代入してください
// ※ 定数=定義したあとで変更することができない変数


// 1.4 1.3で定義した定数「name」に"Bob"を代入して、エラーが発生することを確認してください
// ※ 確認後はコメントアウトしてもらって構いません

var count: Int = 1
print(count)
count = 2
print(count)

let name: String = "John"
print(name)
name = "Bob"
